
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class RentLocker extends javax.swing.JFrame {

    /**
     * Creates new form RentLocker
     */
    public RentLocker() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        WingGroup = new javax.swing.ButtonGroup();
        jRadioButton1 = new javax.swing.JRadioButton();
        Period = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        stName = new javax.swing.JTextField();
        stID = new javax.swing.JTextField();
        lName = new javax.swing.JLabel();
        lID = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        RbC = new javax.swing.JRadioButton();
        RbB = new javax.swing.JRadioButton();
        RbA = new javax.swing.JRadioButton();
        lLR = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Submit = new javax.swing.JButton();
        Home = new javax.swing.JButton();
        Alockernumber = new javax.swing.JComboBox<>();
        Clockernumber = new javax.swing.JComboBox<>();
        Blockernumber = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        Logout = new javax.swing.JButton();
        Period_1 = new javax.swing.JRadioButton();
        Period2 = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();

        jRadioButton1.setText("jRadioButton1");

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Rent a Locker");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        stName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stNameActionPerformed(evt);
            }
        });

        lName.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lName.setForeground(new java.awt.Color(0, 51, 102));
        lName.setText(" Student Name ");

        lID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lID.setForeground(new java.awt.Color(0, 51, 102));
        lID.setText(" Student ID");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 51, 102));
        jLabel3.setText("Rental Period");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("Wing");

        RbC.setBackground(new java.awt.Color(255, 255, 255));
        WingGroup.add(RbC);
        RbC.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        RbC.setForeground(new java.awt.Color(0, 51, 102));
        RbC.setText("C");
        RbC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RbCActionPerformed(evt);
            }
        });

        RbB.setBackground(new java.awt.Color(255, 255, 255));
        WingGroup.add(RbB);
        RbB.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        RbB.setForeground(new java.awt.Color(0, 51, 102));
        RbB.setText("B");
        RbB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RbBActionPerformed(evt);
            }
        });

        RbA.setBackground(new java.awt.Color(255, 255, 255));
        WingGroup.add(RbA);
        RbA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        RbA.setForeground(new java.awt.Color(0, 51, 102));
        RbA.setText("A");
        RbA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RbAActionPerformed(evt);
            }
        });

        lLR.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lLR.setForeground(new java.awt.Color(0, 51, 102));
        lLR.setText("Locker Rental");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LOGOO.PNG"))); // NOI18N

        Submit.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Submit.setForeground(new java.awt.Color(0, 51, 102));
        Submit.setText("Submit");
        Submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitActionPerformed(evt);
            }
        });

        Home.setBackground(new java.awt.Color(255, 255, 255));
        Home.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Home.setForeground(new java.awt.Color(0, 51, 102));
        Home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Home.png"))); // NOI18N
        Home.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HomeActionPerformed(evt);
            }
        });

        Alockernumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Alockernumber.setForeground(new java.awt.Color(0, 51, 102));
        Alockernumber.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "97", "152", "160", "66", "85", "108" }));
        Alockernumber.setSelectedIndex(-1);
        Alockernumber.setEnabled(false);

        Clockernumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Clockernumber.setForeground(new java.awt.Color(0, 51, 102));
        Clockernumber.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "988", "996", "1034", "1047", "1109", "1273" }));
        Clockernumber.setSelectedIndex(-1);
        Clockernumber.setEnabled(false);

        Blockernumber.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Blockernumber.setForeground(new java.awt.Color(0, 51, 102));
        Blockernumber.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "345", "401", "462", "523", "577", "582" }));
        Blockernumber.setSelectedIndex(-1);
        Blockernumber.setEnabled(false);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 51, 102));
        jLabel5.setText("Locker number");

        Logout.setBackground(new java.awt.Color(255, 255, 255));
        Logout.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Logout.setForeground(new java.awt.Color(0, 51, 102));
        Logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/LOGOUT.png"))); // NOI18N
        Logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogoutActionPerformed(evt);
            }
        });

        Period_1.setBackground(new java.awt.Color(255, 255, 255));
        Period.add(Period_1);
        Period_1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Period_1.setForeground(new java.awt.Color(0, 51, 102));
        Period_1.setText("1");
        Period_1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Period_1ActionPerformed(evt);
            }
        });

        Period2.setBackground(new java.awt.Color(255, 255, 255));
        Period.add(Period2);
        Period2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Period2.setForeground(new java.awt.Color(0, 51, 102));
        Period2.setText("2");
        Period2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Period2ActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 102));
        jLabel6.setText("Semster");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Home, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Logout, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(105, 105, 105)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(247, 247, 247)
                        .addComponent(lLR)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(Submit, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Period_1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(39, 39, 39)
                                            .addComponent(RbA, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(39, 39, 39)
                                            .addComponent(Alockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(46, 46, 46)
                                        .addComponent(RbB, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Blockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Period2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(81, 81, 81)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(44, 44, 44)
                                                .addComponent(RbC, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(Clockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lID, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lName)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(stName, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(stID, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(91, 91, 91))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(Home)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Logout)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lLR)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lName))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lID))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Period_1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Period2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6)))
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(RbA, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RbB, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RbC, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Alockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Blockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Clockernumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(Submit)
                .addGap(97, 97, 97))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 742, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RbCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RbCActionPerformed
        // TODO add your handling code here:
        if (RbC.isSelected()){
        Clockernumber.setEnabled(true); 
        Alockernumber.setEnabled(false); 
        Blockernumber.setEnabled(false); 
//        }
//        else {
//            JOptionPane.showMessageDialog(rootPane,"Choose a Wing","Locker Wing" ,JOptionPane.ERROR_MESSAGE);
      }
    }//GEN-LAST:event_RbCActionPerformed

    private void stNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_stNameActionPerformed

    private void SubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitActionPerformed
       
      
        int InsLockersatus;
        String stNames =  stName.getText();
        String STid =  stID.getText();
        
        int total=1;
        String  IdStr = stID.getText();
        int IdLength = IdStr.length();
        if (Period_1.isSelected()){
       total=50;}
        if (Period2.isSelected()){
       total=100;
       
       }
       try {
            if (IdLength == 10){
           
             Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/CSHJ", "cshj", "123");
                Statement stat = con.createStatement();
           if (Period_1.isSelected()) {
                if (RbA.isSelected()){
               if (Alockernumber.getSelectedIndex()==0) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,97);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);           
                  
                  
            InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Alockernumber.getSelectedIndex()==1) {
                                               PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,152);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Alockernumber.getSelectedIndex()==2) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,160);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
             InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Alockernumber.getSelectedIndex()==3) {
                     PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,66);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Alockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,85);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Alockernumber.getSelectedIndex()==5) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,108);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }
                if (RbB.isSelected()){
               if (Blockernumber.getSelectedIndex()==0) {
                                     PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,345);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Blockernumber.getSelectedIndex()==1) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,401);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Blockernumber.getSelectedIndex()==2) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,462);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Blockernumber.getSelectedIndex()==3) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,523);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Blockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,577);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Blockernumber.getSelectedIndex()==5) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,582);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }
                
                
            if (RbC.isSelected()){
               if (Clockernumber.getSelectedIndex()==0) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,988);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Clockernumber.getSelectedIndex()==1) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,996);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Clockernumber.getSelectedIndex()==2) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1034);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Clockernumber.getSelectedIndex()==3) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1047);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Clockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1109);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Clockernumber.getSelectedIndex()==5) {
                                    PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1273);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }
           
           
           }if (Period2.isSelected()) {
                if (RbA.isSelected()){
               if (Alockernumber.getSelectedIndex()==0) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,97);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);           
                  
                  
            InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Alockernumber.getSelectedIndex()==1) {
                                               PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,152);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Alockernumber.getSelectedIndex()==2) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,160);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
             InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Alockernumber.getSelectedIndex()==3) {
                     PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,66);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Alockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,85);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Alockernumber.getSelectedIndex()==5) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,108);
      InsLocker.setString(4,"A");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }
                if (RbB.isSelected()){
               if (Blockernumber.getSelectedIndex()==0) {
                                     PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,345);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
     InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Blockernumber.getSelectedIndex()==1) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,401);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Blockernumber.getSelectedIndex()==2) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,462);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Blockernumber.getSelectedIndex()==3) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,523);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Blockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,577);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Blockernumber.getSelectedIndex()==5) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,582);
      InsLocker.setString(4,"B");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }
                
                
            if (RbC.isSelected()){
               if (Clockernumber.getSelectedIndex()==0) {
                                       PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,988);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
                  if (Clockernumber.getSelectedIndex()==1) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,996);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
                   if (Clockernumber.getSelectedIndex()==2) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1034);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              } 
               if (Clockernumber.getSelectedIndex()==3) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1047);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Clockernumber.getSelectedIndex()==4) {
                                      PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1109);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
         InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
             if (Clockernumber.getSelectedIndex()==5) {
                                    PreparedStatement  InsLocker = con.prepareStatement( "INSERT INTO LOCKER" 
                                              +"(STUDENTNAME, STDID ,LOCKERNUM , WING,PERIODA )"
                                              +"VALUES (?,?,?,?,?)");
     InsLocker.setString(1,stNames);
     InsLocker.setString(2,STid);
     InsLocker.setInt(3,1273);
      InsLocker.setString(4,"C");
     InsLocker.setInt(5,1);
        InsLockersatus= InsLocker.executeUpdate();
                       if ( InsLockersatus==1 ) {
                       
               JOptionPane.showMessageDialog(null, "Your Locker has been Booked, Total Price:"+ total +" SAR", "Confirmation", JOptionPane.INFORMATION_MESSAGE);
                       }
              }
         }}
            }
       
        else {
                JOptionPane.showMessageDialog(null, "Please enter your ID  correctly ","Missing Information", JOptionPane.ERROR_MESSAGE);
            }
       
       }
       catch (SQLException ex) {
                 JOptionPane.showMessageDialog(rootPane, ex.getMessage());
            }
       
    }//GEN-LAST:event_SubmitActionPerformed

    private void RbAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RbAActionPerformed
        // TODO add your handling code here:
        if (RbA.isSelected()){
        Alockernumber.setEnabled(true);
        Clockernumber.setEnabled(false); 
        Blockernumber.setEnabled(false); 
//        else {
//            JOptionPane.showMessageDialog(rootPane,"Choose a Wing","Locker Wing" ,JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_RbAActionPerformed

    private void RbBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RbBActionPerformed
        // TODO add your handling code here:
        
       if (RbB.isSelected()){
        Blockernumber.setEnabled(true);
       Clockernumber.setEnabled(false); 
        Alockernumber.setEnabled(false); 
       }
//        else {
//            JOptionPane.showMessageDialog(rootPane,"Choose a Wing","Locker Wing" ,JOptionPane.ERROR_MESSAGE);
//        }
    }//GEN-LAST:event_RbBActionPerformed

    private void HomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HomeActionPerformed
dispose();
Home.setToolTipText("Home page");
// TODO add your handling code here:
    }//GEN-LAST:event_HomeActionPerformed

    private void LogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogoutActionPerformed
        // idcard.dispatchEvent(new WindowEvent(rootpane, WindowEvent.WINDOW_CLOSING));
        // username.dispatchEvent(new WindowEvent(username, WindowEvent.WINDOW_CLOSING));
        //idcard.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //JDialog dialog = new JDialog(idcard);
        //dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        // idcard().dispose();
Logout.setToolTipText("Logout");
        int a = JOptionPane.showConfirmDialog(null, "Are you sure?");
        if (a == JOptionPane.YES_OPTION){
            dispose();
              new username().setVisible(false);
            new OOpLogin().setVisible(true);
        }
    }//GEN-LAST:event_LogoutActionPerformed

    private void Period_1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Period_1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Period_1ActionPerformed

    private void Period2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Period2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Period2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RentLocker.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RentLocker.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RentLocker.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RentLocker.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RentLocker().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Alockernumber;
    private javax.swing.JComboBox<String> Blockernumber;
    private javax.swing.JComboBox<String> Clockernumber;
    private javax.swing.JButton Home;
    private javax.swing.JButton Logout;
    private javax.swing.ButtonGroup Period;
    private javax.swing.JRadioButton Period2;
    private javax.swing.JRadioButton Period_1;
    private javax.swing.JRadioButton RbA;
    private javax.swing.JRadioButton RbB;
    private javax.swing.JRadioButton RbC;
    private javax.swing.JButton Submit;
    private javax.swing.ButtonGroup WingGroup;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JLabel lID;
    private javax.swing.JLabel lLR;
    private javax.swing.JLabel lName;
    private javax.swing.JTextField stID;
    private javax.swing.JTextField stName;
    // End of variables declaration//GEN-END:variables
}
